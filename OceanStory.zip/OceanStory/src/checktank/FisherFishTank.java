package checktank;

public class FisherFishTank {

	int total_fish; //�� ������ ����
	
	int salmon;
	int flatfish;
	int shrimp;
	int blowfish;
	int tuna;
	
//	public add_salmon()
//	//salmon+
//
//	public add_flatfish()
//	//flatfish+
//
//	public add_shrimp()
//	//shrimp+
//
//	public add_blowfish()
//	//blowfish+
//
//	public add_tuna()
//	//tuna+
//
//	public minus_salmon()
//	//salmon-
//
//	public minus_flatfish()
//	//flatfish-
//
//	public minus_shrimp()
//	//shrimp-
//
//	public minus_blowfish()
//	//blowfish-
//
//	public minus_tuna()
//	//tuna-
}
