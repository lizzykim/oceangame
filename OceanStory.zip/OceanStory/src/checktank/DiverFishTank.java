package checktank;

public class DiverFishTank {

	int total_fish; //�� ������ ����
	
	int sora;
	int seaweed;
	int crab;
	int octopus;
	int abalone; 
	
//	public add_sora()
//	//sora+
//
//	public add_seaweed()
//	//seaweed+
//
//	public add_crab()
//	//crab +
//
//	public add_octopus()\
//	//octopus+
//
//	 public add_abalone()
//	//abalone+
//
//	 public minus_sora()
//	//sora-
//
//	 public minus_seaweed()
//	//seaweed-
//
//	public minus_crab()
//	//crab-
//
//	public minus_octopus()
//	//octopus-
//
//	public minus_abalone()
//	//abalone-
	
}
