package gocatch;

public class gocatch_main {

}
