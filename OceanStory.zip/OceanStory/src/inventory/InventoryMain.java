package inventory;

public class InventoryMain {

}
